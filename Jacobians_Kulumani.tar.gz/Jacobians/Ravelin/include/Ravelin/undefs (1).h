/****************************************************************************
 * Copyright 2013 Evan Drumwright
 * This library is distributed under the terms of the Apache V2.0 
 * License (obtainable from http://www.apache.org/licenses/LICENSE-2.0).
 ****************************************************************************/

#undef REAL 
#undef EPS
#undef QUAT
#undef AANGLE
#undef MATRIXN 
#undef MATRIX3
#undef MATRIX2
#undef SHAREDVECTORN
#undef CONST_SHAREDVECTORN
#undef SHAREDMATRIXN
#undef CONST_SHAREDMATRIXN
#undef VECTORN 
#undef VECTOR2
#undef VECTOR3
#undef POSE3 
#undef CONST_COLUMN_ITERATOR
#undef CONST_ROW_ITERATOR
#undef COLUMN_ITERATOR 
#undef ROW_ITERATOR    
#undef SVECTOR6 
#undef SFORCE
#undef SMOMENTUM
#undef SVELOCITY
#undef SACCEL 
#undef SPATIAL_AB_INERTIA
#undef SPATIAL_RB_INERTIA 
#undef LINALG 
#undef SPARSEMATRIXN
#undef SPARSEVECTORN
#undef POSE2
#undef ROT2
#undef ORIGIN2
#undef ORIGIN3
#undef OPS
#undef TRANSFORM3
#undef TRANSFORM2
#undef JOINT
#undef FIXEDJOINT
#undef UNIVERSALJOINT
#undef REVOLUTEJOINT
#undef SPHERICALJOINT
#undef PRISMATICJOINT
#undef MOVINGTRANSFORM3

