
// Test Functions
void TestArithmetic();
void TestBlockOperations();
void TestLinearAlgebra();


int main(){
    TestArithmetic();
    TestLinearAlgebra();
}
