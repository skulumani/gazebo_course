export GAZEBO_PLUGIN_PATH=$GAZEBO_PLUGIN_PATH:/home/drum/gazebo-course/Jacobians/debug
export GAZEBO_MODEL_PATH=/home/drum/gazebo-course/Jacobians:$GAZEBO_MODEL_PATH

